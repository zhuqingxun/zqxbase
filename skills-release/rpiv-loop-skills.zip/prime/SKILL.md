---
name: rpiv-loop:prime
description: 使用代码库理解项目，加载项目上下文
allowed-tools: Read, Bash, Glob, Grep
version: 2.17.6
---

> `<rpiv-loop-root>` 解析顺序：环境变量 `RPIV_LOOP_ROOT` -> `CLAUDE_PLUGIN_ROOT` -> 当前插件根目录；均不存在时停止并请用户配置 `RPIV_LOOP_ROOT` 或 `CLAUDE_PLUGIN_ROOT`。

# Prime: 加载项目上下文

## 目标

通过分析结构、文档和关键文件，建立对代码库的全面理解。

## 前置初始化

首次执行前调用（幂等，已存在则静默跳过）：

```bash
uv run --no-project python <rpiv-loop-root>/tools/ensure_project_dod.py
```

该脚本若发现 `rpiv/dod.yaml` 缺失则从 `<rpiv-loop-root>/tools/dod_template.yaml` 拷贝初始化；已存在则静默跳过。确保项目级 DoD 通用门在后续 RPIV 各阶段可用。

## 流程

### 1. 分析项目结构

列出所有跟踪的文件：
!`git ls-files`

显示目录结构：
优先运行 `rg --files` 或 `git ls-files`。如果需要目录树，Windows PowerShell 使用 `Get-ChildItem -Recurse -Depth 3`；Unix 且安装了 GNU tree 时才使用 `tree -L 3 -I 'node_modules|__pycache__|.git|dist|build'`。

### 2. 阅读核心文档

- 阅读 CLAUDE.md 或类似的全局规则文件
- 阅读项目根目录和主要目录中的 README 文件
- 阅读任何架构文档，一般包括总体架构文档和docs下的子架构文档

### 3. 识别关键文件

基于结构，识别并阅读：
- 主入口点（main.py、index.ts、app.py 等）
- 核心配置文件（pyproject.toml、package.json、tsconfig.json）
- 关键模型/模式定义
- 重要的服务或控制器文件

### 4. 了解当前状态

检查最近的活动：
!`git log -10 --oneline`

检查当前分支和状态：
!`git status`

## 输出报告

提供涵盖以下内容的简洁摘要：

### 项目概述
- 应用程序的目的和类型，特别关注应用需要解决的问题和最终达成效果
- 主要技术和框架
- 当前版本/状态

### 用户需求
- 需解决的核心问题和用户痛点
- 期望实现的关键目标和最终效果
- 产品预期的形态与用户场景

### 架构
- 整体结构和组织
- 识别的关键架构模式
- 重要目录及其用途

### 技术栈
- 语言和版本
- 框架和主要库
- 构建工具和包管理器
- 测试框架

### 核心原则
- 观察到的代码风格和约定
- 文档标准
- 测试方法

### 当前状态
- 关注基于应用的最终目标，当前已经完成的开发目标，和未完成的开发目标。
- 活动分支
- 最近的更改或开发重点
- 任何即时观察或关注点

**使此摘要易于扫描 - 使用项目符号和清晰的标题。**
