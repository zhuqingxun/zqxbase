---
name: mint:refine
description: >-
  MINT 流水线 Stage 2: 将 ASR 原始转录稿清洁为可读逐字稿。使用 Agent Team 双路交叉校对，
  包含架构师（全局分析）、双路校对员（交叉验证）、审查员（质量把关）、人工澄清环节（消除歧义）。
  支持两种模式：保守（仅修错字和口水词）、适度（句子级优化，默认）。
  当用户调用 /mint:refine 时触发，将 02_原始稿/ 目录下的 ASR 转录稿清洁为 03_校对稿/ 目录下的逐字稿。
argument-hint: "<工作目录> [保守|适度] [--脱敏]"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Agent, AskUserQuestion, TaskCreate, TaskUpdate, SendMessage, TaskStop
version: 2.1.9
---

# mint:refine — 校对清洁

> **`{MINT_REF}` 路径约定**：指 mint 插件的 `references/` 目录，`{MINT_SCRIPTS}` 为同级 `scripts/` 目录。首次引用时通过
> `Glob("**/plugins/mint/references/lessons-learned.md")` 定位，多结果时优先非 `marketplaces/` 路径（私有开发版）。

将 ASR 原始转录稿清洁为可读逐字稿。使用 Agent Team 双路交叉校对，包含架构师、双路校对员、审查员、人工澄清环节。

## 用法

```
/mint:refine <工作目录> [模式] [--脱敏]
```

- `<工作目录>`：MINT 会议目录路径（包含 `02_原始稿/` 子目录）
- `[模式]`：可选，`保守` / `适度`（默认）
- `--脱敏`：同时生成脱敏版本。脱敏规则参见 `{MINT_REF}/lessons-learned.md` 第三节

示例：
- `/mint:refine D:/WORK/meetings/2026-03-20-周会` — 适度模式校对
- `/mint:refine D:/WORK/meetings/2026-03-20-周会 保守` — 仅修错字和口水词
- `/mint:refine D:/WORK/meetings/2026-03-20-周会 --脱敏` — 适度模式校对 + 生成脱敏版

## 目录结构

refine 工作在 MINT 标准目录结构中：

```
{会议名}/
├── 01_音频/     ← 音频文件
├── 02_原始稿/       ← ASR 转录稿（输入）
│   └── {name}_原始稿.md
├── 03_校对稿/     ← refine 输出
│   ├── {name}_校对稿.md
│   └── old/   ← 历史版本
├── 04_编辑稿/  ← polish 阶段输出
├── 05_分析稿/   ← extract 阶段输出
└── meta.yaml  ← 元数据
```

## 架构概览

```
Leader（你）─── 分段 / 协调 / 人工澄清 / 合并 / 输出
  ├── Architect ─── 通读全文 → 上下文指南 + 不确定项清单
  ├── Worker-A1~AN ─ 第一路并行校对（每段含前后重叠区）
  ├── Worker-B1~BN ─ 第二路并行校对（独立于 A 路）
  └── Reviewer ───── 交叉对比 A/B 两版 + 评分 + 终审
```

**核心机制**：人工澄清消除歧义 + 段落重叠区保衔接 + 双路交叉校对提置信度

## 执行流程

### 阶段 0: 初始化（Leader 执行）

1. 读取工作目录下 `02_原始稿/` 中的源文件，用 `wc -m <文件路径>` 统计字符数
2. 解析参数确定模式（默认适度）
3. 按文本长度决定分段数 N：
   - <1 万字: N=2
   - 1-5 万字: N=3
   - >5 万字: N=4
4. 分段策略（带重叠区）：
   - 优先按 Markdown 标题或说话人时间戳分割
   - 每段目标 5000-15000 字
   - **重叠区**：每段前后各扩展 500 字（只读上下文，不修改）
5. **团队机制**（无需显式创建）：当前 Claude Code harness 无 `TeamCreate`/`TeamDelete`，团队为单一 implicit flat team——用 `Agent` 工具 spawn 的每个 named agent（Architect / Worker-A/B / Reviewer）自动加入，`subagent_type: general-purpose`、不传 `team_name`（已废弃且被忽略），后续用 `SendMessage` 按 name 寻址。与 `rpiv-loop:biubiubiu` 步骤 2 对齐

### 阶段 1: 架构分析（串行，Architect）

Architect 通读全文，输出两份文档：

**文档 A：上下文指南**（含术语表/人物关系/话题结构/专有名词/风格建议/错字预警）

**文档 B：不确定项清单**

Architect 将所有拿不准的项目按影响程度分级：

```
### 高优先级（影响整句含义）
1. "完全无味的人选"（00:02:24）→ 可能是：A.具体的人选 B.未定的人选 C.其他
2. "一个酒吧"（00:22:11）→ 可能是：A.某人名 B.搭档/伙伴 C.其他

### 中优先级（人名/术语确认）
3. "泽哥"和"浙哥"是同一人吗？
4. "王总"和"汪总"是同一人吗？
5. Speaker 1 是否为李总？Speaker 2 是否为访谈者？

### 低优先级（可跳过）
6. "趋应为"是否为"不得不配合"？
```

**门禁 1：** Leader 校验上下文指南覆盖度。

### 阶段 1.5: 人工澄清（Leader <-> 用户交互）

Leader 将不确定项通过 AskUserQuestion 分批呈现给用户：

- 每批最多 4 个问题（AskUserQuestion 限制）
- 高优先级优先，低优先级可标注"跳过则 AI 自行判断"
- 用户确认后，Leader 更新上下文指南中的对应条目
- **同时确认说话人身份**：用户可选择在输出中用真名替换 Speaker 标记

更新后的上下文指南分发给所有 Worker 和 Reviewer。

**高优先级问题的新类型——语境可疑表达**（2026-04-08 新增）：

若 Architect 在不确定项清单中标出"语法通顺但语境冲突"的表达（参考 `{MINT_REF}/architect-prompt.md` 第 7 节），这类问题必须在阶段 1.5 优先询问用户。示例：

> "第 X 段有一句「现有的干部全是男的」，但前后段讨论的是招博士生、新人管新人。请确认原意：
> - A) 确实是性别描述
> - B) ASR 严重失真，应为"全是难干成的"
> - C) 其他（请说明）"

这类问题的特点：**用户识别成本低**（一看就懂）、**AI 猜错成本高**（整段语义反转）、**Worker 层结构性不可解**（只能看局部）。是阶段 1.5 人工澄清机制的最佳应用场景。

### 阶段 2: 双路并行校对

为每段启动 **2 个独立 Worker**（A 路和 B 路），总共 2N 个 Worker 并行。

每个 Worker 拿到：
```
[前 500 字只读上下文 - 灰色，不修改]
===== 校对起点 =====
{Worker 负责的 ~5000-15000 字}
===== 校对终点 =====
[后 500 字只读上下文 - 灰色，不修改]
```

A 路和 B 路使用相同的上下文指南和校对规则，但独立执行、互不通信。

### 阶段 3: 交叉审查

Reviewer 对每段的 A/B 两版输出进行交叉对比：

```
对比策略：
- A 和 B 做了相同修改 → 直接采纳（高置信度）
- A 和 B 做了不同修改 → Reviewer 选择更优版本或合并
- A 改了 B 没改（或反之）→ 重点审查（可能是误删或遗漏）
```

同时执行五维评分和抽样交叉校验。

**退回机制**：总分 <80 退回对应 Worker 修改（取 A/B 中较好的那个退回），最多 2 轮。

### 阶段 4: 合并终审

1. Leader 按段落顺序合并（去除重叠区内容，保留校对区）
2. Reviewer 终审：段落衔接、术语统一、总分 >= 85 通过
3. 如用户在阶段 1.5 确认了说话人身份，替换 Speaker 标记为真名

### 阶段 5: 输出与关闭

1. 写入 `03_校对稿/{name}_校对稿.md`（如已有旧版本，先移至 `03_校对稿/old/`）
2. 如果指定了 `--脱敏`，基于校对结果生成脱敏版本（移除受访者姓名/岗位/职级/个人经历细节/时间戳），写入 `03_校对稿/{name}_校对稿_脱敏.md`。脱敏规则详见 `{MINT_REF}/lessons-learned.md` 第三节
3. **词表沉淀**：将本次人工澄清确认的新词条 + Reviewer 交叉审查中发现的新错字，沉淀到 `{MINT_REF}/lessons-learned.md`。具体操作：
   - 逐条对比已有高频错字表，**已有的追加变体**（如已有"ASR错误A→正确A"，新发现"ASR错误B"则追加为"ASR错误A/ASR错误B→正确A"）
   - **新发现的**追加到表格末尾，格式与现有条目一致
   - 如有新的语义陷阱或 Worker 失败模式，追加到对应章节
   - 更新文件末尾的「最后更新」日期
4. 更新 `meta.yaml` 中 refine 阶段状态
5. 终端输出：统计报告 + 质量评分表 + 变更详情 + 人工澄清记录 + **词表沉淀条数**
6. 关闭团队：对仍活跃的 named teammate 发 `SendMessage` `{"type": "shutdown_request"}`，agent approve 后自行终止；无响应用 `TaskStop`（task_id = spawn 返回的 agent_id）兜底。当前 harness 无 `TeamDelete`

## meta.yaml 更新

refine 完成后需更新 meta.yaml 的 stages.refine 部分：

```yaml
stages:
  refine:
    status: completed        # pending | in_progress | completed
    version: 3               # 版本号，每次重跑 +1
    completed_at: 2026-03-20T15:00:00
    params:
      mode: moderate         # conservative | moderate
      model: gpt-4o
      desensitized: false    # 是否生成了脱敏版本
    quality:
      fidelity: 92
      fluency: 88
      consistency: 90
      cleanliness: 95
      format: 98
```

如 meta.yaml 不存在，创建基础结构。如已存在 refine 条目，version +1。

## 两种校对模式

### 保守模式
- 修正：同音错字、独立口水词（嗯/啊/呃）、明显断句错误
- 不动：口语化表达、句子结构、有意义的语气词

### 适度模式（默认）
- 在保守基础上增加：清理所有口水词、精简冗余、口语书面化、语法修正
- **访谈场景增强规则**（2026-04-07 基于实际人工修订 diff 新增）：
  - 访谈者话语按 A 类（提问）/B 类（转述）/C 类（短促回应）分级处理，B/C 类默认删除
  - 受访者跨越访谈者短回应的连续段落应合并为一段
  - 话题内受访者重复观点去重，保留最清晰的一次
  - 粗口默认删除，保留是例外（仅构成情感强度的核心表达才保留）
  - 访谈者的感叹和元评论（"我觉得很有价值""你这个洞察很关键"）默认删除
- 保持：段落结构、核心观点、说话人语气立场

详细的校对模式规则见 `{MINT_REF}/worker-prompt.md`；访谈场景的精简深度校准见 `{MINT_REF}/lessons-learned.md` 第五章。

## 校对通用规则

### 口水词删除测试（所有模式强制执行）

将该词从句子中删除：
- 仍通顺且意思**完全不变** → 可删除
- 不通顺或意思改变 → **不可删除**

### 绝不能删除的内容

- 逻辑连接词：因为、所以、但是、而且、虽然、如果、既然、因此、然而
- 举例词：比如、比如说、例如
- 语义副词：反正、其实、毕竟、至少、主要、关键
- 实义词：想法、问题、办法、情况、态度、原因
- 固定短语：对事不对人、想谈就谈、主要还是
- 时间戳和说话人标记

### 同音错字

不确定的错字优先通过阶段 1.5 人工澄清解决。仍不确定时保留原文。

## 质量评分标准（Reviewer 使用）

| 维度 | 权重 | 说明 |
|------|------|------|
| 忠实度 | 30% | 原意完整保留，无信息误删 |
| 流畅度 | 25% | 通顺自然，书面化程度恰当 |
| 一致性 | 20% | 术语、人名、缩写与上下文指南统一 |
| 清洁度 | 15% | 口水词、错字彻底清理 |
| 格式完整 | 10% | 时间戳、说话人标记完好 |

单段 >= 80 通过，全文终审 >= 85 通过。

## 输出格式

```markdown
## 校对统计

| 指标 | 数值 |
|------|------|
| 原文字数 | 84,098 |
| 校对后字数 | 58,200 |
| 精简比例 | 30.8% |
| 校对模式 | 适度 |
| 团队规模 | 2x4 Worker（双路交叉） |
| 人工澄清 | 6 项已确认 |

### 质量评分

| 段落 | 忠实度 | 流畅度 | 一致性 | 清洁度 | 格式 | 总分 | A/B一致率 |
|------|--------|--------|--------|--------|------|------|----------|
| 第1段 | 95 | 92 | 95 | 93 | 100 | 94 | 87% |
| ... | | | | | | | |

### 人工澄清记录

| # | 原文 | 用户确认 |
|---|------|---------|
| 1 | "完全无味的人选" | → 具体的人选 |
| 2 | "泽哥"="浙哥" | → 是，同一人 |
| ... | | |

## 变更详情（典型示例）
...

已保存: 03_校对稿/{name}_校对稿.md
```

## blocker 自动解除

refine 开始执行前（加载 meta.yaml 之后、进入双路校对之前），先读取 `current.blockers[]`——若存在与 ambiguity 类型相关的旧条目，本次执行过程中重新评估：

- 若 Architect 在新一轮"不确定项清单"中**未再提出**同样文本的歧义（说明 patch 词表或新一轮校对已解决），则该 blocker 自动移除：
  ```bash
  uv run --script {MINT_SCRIPTS}/meta_io.py resolve-blockers "<工作目录>" "<blocker description 中的关键短语>"
  ```
- 日志必须明确输出 `自动解除 blocker: <原 description>`（供审计，PRD BLOCKER-01 断言关键词）。

若本次仍检测到新的歧义/缺输入/待决策，使用：
```bash
uv run --script {MINT_SCRIPTS}/meta_io.py add-blocker "<工作目录>" "ambiguity" "<description>" "<suggested_action>"
```

## 最后一步：更新元数据并输出引导块

1. **刷新 current.last_action + 计算 next_hints**：
   ```bash
   uv run --script {MINT_SCRIPTS}/meta_io.py refresh-last-action "<工作目录>"
   uv run --script {MINT_SCRIPTS}/meta_io.py compute-next-hints "<工作目录>"
   ```
   同时将 `current.cursor` 更新为 `"refine"`、`current.last_action_desc` 更新为 `"完成校对"`（在上述命令之前或通过 Edit 工具写入 meta.yaml）。

2. **渲染引导块**：
   - Read `{MINT_REF}/next-hints-template.md`
   - 用 compute-next-hints 输出的 JSON 填充 `{primary_cmd}` / `{primary_reason}` / `{alternatives_block}`
   - `{alternatives_block}` 按每行 `- {cmd}: {when}` 循环展开，空数组输出单行 `- 无`
   - 原样输出填充后的模板（保留开头的 `---` 分隔线）

## 参考文件

| 文件 | 用途 | 何时读取 |
|------|------|---------|
| `{MINT_REF}/architect-prompt.md` | Architect 指引（含不确定项清单格式） | 阶段 1 |
| `{MINT_REF}/worker-prompt.md` | Worker 校对规则（两种模式+重叠区说明） | 阶段 2 |
| `{MINT_REF}/reviewer-prompt.md` | Reviewer 评分标准+交叉对比策略 | 阶段 3 |
| `{MINT_REF}/lessons-learned.md` | 历次校对积累的经验教训（高频错字表、语义陷阱、脱敏规则等） | Architect 阶段 1 + Reviewer 阶段 3 |

## 异常处理

| 情况 | 处理 |
|------|------|
| Agent 无响应（>5 分钟） | 重新启动 |
| Worker 退回 2 轮仍不合格 | Reviewer 直接修正 |
| 终审 <85 分 | 标记问题段定向修正 |
| 文件过短（<500 字） | 跳过团队模式，Leader 直接校对 |
| 用户跳过所有澄清问题 | AI 按最高置信度选项处理 |
| A/B 两版差异过大（>40%） | Reviewer 逐句对比，必要时引入第三 Worker |

## 团队规模

| 文本长度 | 分段数 N | Worker 总数 | 说明 |
|---------|---------|------------|------|
| <1 万字 | 2 | 4 (2x2) | 双路最小配置 |
| 1-5 万字 | 3 | 6 (2x3) | 标准配置 |
| >5 万字 | 4 | 8 (2x4) | 大文本配置 |

加上 Architect(1) + Reviewer(1)，团队总规模 6-10 个 agent。
