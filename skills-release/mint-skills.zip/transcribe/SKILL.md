---
name: mint:transcribe
description: >-
  MINT 流水线 Stage 1: 语音转文本——调用阿里云百炼平台将录音文件转为带时间戳和说话人标记的原始口水稿。当用户提到"语音转文字""录音转文本""转录""transcribe""把录音转成文字""ASR"时使用。支持 mp3/m4a/wav/flac/ogg 等常见音频格式，自动启用说话人分离。
argument-hint: "<音频文件路径> <人名或会议名>"
allowed-tools: Read, Write, Bash, Glob, Grep, AskUserQuestion, Skill
version: 2.1.11
---


# mint:transcribe — 语音转文本

> **路径约定**：`{MINT_REF}` = mint 插件 `references/` 目录，`{MINT_SCRIPTS}` = 同级 `scripts/` 目录。
> 首次引用时通过 `Glob("**/plugins/mint/references/lessons-learned.md")` 定位，多结果时优先非 `marketplaces/` 路径。
> `{MINT_SCRIPTS}` 与 `{MINT_REF}` 在同一插件根目录下。

调用阿里云百炼平台（DashScope Fun-ASR）将录音转为口水稿，自动启用说话人分离和标点恢复。

## 用法

```
/mint:transcribe <音频文件路径> <人名或会议名>
```

示例：
- `/mint:transcribe D:\Downloads\interview.mp3 张三访谈`
- `/mint:transcribe "D:\华为云盘\录音\meeting.m4a" 产品评审会`

## 执行流程

### 前置检查：API Key 配置

在执行任何操作之前，先确认百炼 API Key 已配置：

```bash
echo $DASHSCOPE_API_KEY
```

**已配置**（输出非空）→ 跳过此步骤，进入第一步。

**未配置**（输出为空）→ 启动引导式配置流程：

1. 使用 AskUserQuestion 告知用户并提供选项：
   - **"我已有百炼 API Key"** — 直接输入 key
   - **"我没有，引导我获取"** — 输出获取指引（见下方）
   - **"跳过，我自行配置环境变量"** — 终止引导，提示 `export DASHSCOPE_API_KEY="sk-..."`

2. **引导获取 API Key**（选择"引导我获取"时展示）：
   ```
   请按以下步骤获取百炼 API Key：
   1. 访问 https://bailian.console.aliyun.com/
   2. 登录阿里云账号（没有则需注册）
   3. 进入控制台 → 左侧菜单「API-KEY 管理」
   4. 点击「创建 API Key」，复制生成的 sk-... 格式密钥
   ```

3. **用户提供 key 后，验证有效性**：
   ```bash
   uv run python -c "
   import dashscope
   dashscope.api_key = '{用户输入的key}'
   r = dashscope.Models.list()
   print('VALID' if r.status_code == 200 else f'INVALID: {r.message}')
   "
   ```
   - VALID → 继续配置
   - INVALID → 提示 key 无效，请重新检查

4. **持久化配置**（使用 AskUserQuestion 让用户选择）：
   - **"写入 settings.json（推荐）"** — 调用 `/update-config` 将 `DASHSCOPE_API_KEY` 写入 `~/.claude/settings.json` 的 `env` 字段，跨会话永久生效
   - **"仅本次会话"** — 执行 `export DASHSCOPE_API_KEY="sk-..."`，重启后需重新配置

### 第一步：解析参数

从用户指令中提取：
- **音频路径**：本地文件绝对路径
- **名称**：用于目录命名和输出文件命名

验证音频文件存在，检查格式是否支持（mp3/m4a/wav/flac/ogg/opus/wma/aac/mp4/avi/mkv/mov）。

### 第二步：初始化工作目录

判断目录结构是否已存在。如果是首次运行，在音频文件所在目录下创建完整的 MINT 工作目录：

```
{name}/
├── 01_音频/           ← 复制或移动原始音频到此处
├── 02_原始稿/
│   └── old/
├── 03_校对稿/
│   └── old/
├── 04_编辑稿/
│   └── old/
├── 05_分析稿/
│   └── old/
└── meta.yaml
```

创建初始 `meta.yaml`（严格按以下字段顺序写入，不要按字母序）：
```yaml
project: "{name}"
created: {当前日期}
source_audio: "{音频文件名}"

stages:
  transcribe:
    status: pending
  refine:
    status: pending
  polish:
    status: pending
  extract:
    status: pending

revisions: []

desensitization:
  name_map: {}

intent:
  goal: ""
  deliverables: []
  skip_stages: []
  scenario: ""

current:
  cursor: ""
  last_action: null
  last_action_desc: ""
  blockers: []

next_hints:
  primary:
    cmd: ""
    reason: ""
  alternatives: []
```

说明：`intent` / `current` / `next_hints` 三块为空初始值，后续各 skill 会刷新。`intent.goal` 和 `intent.deliverables` 为空时，读取方（如 `mint:next`）会从工作区级 `.mint/workspace.yaml` 继承。

如果工作目录已存在（meta.yaml 已有），跳过创建，直接进入转录。

### 第三步：检查依赖

确认转录脚本的依赖可用：
```bash
uv run --script {MINT_SCRIPTS}/transcribe.py --help 2>/dev/null || echo "需要安装依赖"
```

脚本使用 PEP 723 inline metadata，`uv run --script` 会自动处理依赖安装。

### 第四步：执行转录

运行转录脚本：
```bash
uv run --script {MINT_SCRIPTS}/transcribe.py "<音频路径>" "<名称>"
```

脚本会：
1. 读取 API Key（从环境变量 `DASHSCOPE_API_KEY` 或密钥文件）
2. 上传音频文件到阿里云 OSS（签名 URL，转录后自动清理）
3. 提交异步转录任务（Fun-ASR 模型 + 说话人分离）
4. 轮询等待完成（每 5 秒检查，显示进度）
5. 解析结果，合并同一说话人的连续语句
6. 格式化输出为 markdown

### 第五步：整理输出

脚本默认输出到音频同目录。需要将输出文件移动到工作目录中：

1. 将脚本输出的 `{name}_原始.md` 移动到 `{工作目录}/02_原始稿/{name}_原始稿.md`
2. 如果 `02_原始稿/` 中已有同名文件，先将旧版移动到 `02_原始稿/old/{name}_原始稿_v{N}.md`

### 第六步：更新 meta.yaml

通过 meta_io CLI 写入 transcribe 阶段状态与游标（统一写入口，自动保序 + 枚举校验，**不要手写 YAML**）：

```bash
uv run --script {MINT_SCRIPTS}/meta_io.py set-stage "<工作目录>" transcribe --status completed --version {N} --param model=fun-asr --param speakers={识别到的说话人数}
uv run --script {MINT_SCRIPTS}/meta_io.py set-cursor "<工作目录>" transcribe --desc "完成转录"
```

- `--status completed` 时 `completed_at` 自动填当前 ISO 时间，无需手传。
- `{N}`：首次转录传 `1`；重新转录时在上次 version 基础上递增。
- `--param` 的值自动 JSON 转型（`speakers=2` → int，`model=fun-asr` → 原样 str）。

### 第七步：验证并报告

1. 确认输出文件已在正确位置
2. 报告：
   - 工作目录路径
   - 输出文件路径和字数
   - 识别到的说话人数量
   - 音频时长

### 最后一步：更新元数据并输出引导块

1. **刷新 current.last_action + 计算 next_hints**：
   ```bash
   uv run --script {MINT_SCRIPTS}/meta_io.py refresh-last-action "<工作目录>"
   uv run --script {MINT_SCRIPTS}/meta_io.py compute-next-hints "<工作目录>"
   ```
   第二条命令同时输出 JSON（含 primary.cmd / primary.reason / alternatives[]）到 stdout。

2. **渲染引导块**：
   - Read `{MINT_REF}/next-hints-template.md`
   - 用 compute-next-hints 输出的 JSON 填充占位符：
     - `{primary_cmd}` ← primary.cmd
     - `{primary_reason}` ← primary.reason
     - `{alternatives_block}` ← 按每行 `- {cmd}: {when}` 循环展开；空数组输出单行 `- 无`
   - 原样输出填充后的模板（保留开头的 `---` 分隔线）

## 输出格式

```markdown
00:00:12 Speaker 1

这个问题很好，我觉得核心还是在于我们整个选拔机制的问题。

00:00:35 Speaker 2

你说的选拔机制，具体是指哪些环节？

00:00:42 Speaker 1

首先是任职资格体系，这个已经成为一个枷锁了...
```

- 时间戳格式：`HH:MM:SS`
- 说话人标记：`Speaker 1`、`Speaker 2`...（保留数字编号）
- 同一说话人的连续发言合并为一段
- 输出路径：`{工作目录}/02_原始稿/{name}_原始稿.md`

## API 配置

- **平台**：阿里云百炼（DashScope）
- **模型**：Fun-ASR（Paraformer-v2，中文 SOTA 级别）
- **API Key**：从密钥文件读取「阿里bailian (标准 DashScope)」条目
- **功能开关**：说话人分离 + 标点恢复 + 时间戳

## 异常处理

| 情况 | 处理 |
|------|------|
| 音频文件不存在 | 报错并提示检查路径 |
| API Key 无效 | 提示检查密钥文件或环境变量 |
| 转录任务失败 | 显示错误信息，建议检查音频格式或文件大小 |
| 超时（>30 分钟未完成） | 报告 task_id 供手动查询 |
| 说话人分离失败 | 降级为不分说话人的转录 |
| 工作目录已存在 | 保留现有目录，转录结果版本递增 |
