---
name: mint:patch
description: >-
  MINT 词表修正——维护 ASR 纠错词表并批量刷新已生成的全部稿件。
  当用户发现转录或校对结果中有同音错字需要修正时使用。
  触发场景："加到词表""刷新稿件""纠错""这个词错了应该是XX""补丁""更新词表"，
  或在阅读任意稿件时指出某个词识别错误（如"XX应该是YY"）。
argument-hint: "<纠错指令> [<工作目录>] [--from 校对稿|编辑稿|分析稿]"
allowed-tools: Read, Write, Edit, Bash, Grep, Glob, AskUserQuestion
version: 2.1.10
---


# MINT 词表修正（Patch）

> **`{MINT_REF}` 路径约定**：指 mint 插件的 `references/` 目录。首次引用时通过
> `Glob("**/plugins/mint/references/lessons-learned.md")` 定位，多结果时优先非 `marketplaces/` 路径（私有开发版）。

将 ASR 纠错经验沉淀到词表，并批量修正工作目录中已生成的全部稿件——一次修正，全局生效。

## 用法

```
/mint:patch <纠错指令> [<工作目录>] [--from <起始阶段>]
```

参数说明：
- `<纠错指令>`：纠错内容（"XX应该是YY"）
- `<工作目录>`：可选，MINT 工作目录路径。未指定时从对话上下文推断或询问用户
- `--from <起始阶段>`：可选，指定从哪个阶段开始替换，向下游级联。可选值：`校对稿`/`refine`（默认）、`编辑稿`/`polish`、`分析稿`/`extract`（同时支持中英文值）

示例：
- `/mint:patch "素莹的点"应该是"速赢"` — 从校对稿开始，级联到编辑稿、分析稿
- `/mint:patch 把"人才盘电"改成"人才盘点" --from 编辑稿` — 只改编辑稿和分析稿，不动校对稿
- `/mint:patch "素质模形"改成"素质模型" --from 分析稿` — 只改分析稿

## 工作流程

### 第一步：解析纠错信息

从用户消息中提取：

| 字段 | 说明 | 必需 |
|------|------|------|
| 错误词 | ASR 误识别的文本 | 是 |
| 正确词 | 正确写法 | 是 |
| 语境说明 | 出现场景（如"讨论基层经验推广时"） | 否，可根据上下文推断 |

用户表达方式多样：
- "XX 应该是 YY" / "把 XX 改成 YY" / "XX->YY"
- 一次可能提供多条纠错，全部收集后批量处理

### 第二步：更新词表

词表文件位置：`{MINT_REF}/lessons-learned.md`

1. Read 词表文件
2. 在 ASR 同音错字高频表 中检查是否已有相同条目（去重）
3. 追加新条目到表格末尾，保持格式一致：
   ```
   | 错误词 | 正确词 | 语境说明 |
   ```
4. 更新文件末尾的「最后更新」日期为当天

### 第三步：确定搜索范围

**定位工作目录**（优先级从高到低）：
1. 用户明确指定了目录 -> 用该目录
2. 当前对话上下文中有明确的工作目录 -> 用该目录
3. 用户提到具体人名或会议名 -> 尝试在常用工作路径下定位
4. 都没指定 -> 通过 AskUserQuestion 询问用户指定工作目录

**搜索规则（下游级联）**：

根据 `--from` 参数确定搜索范围，从指定阶段开始向下游级联：

| --from 值 | 搜索范围 | 说明 |
|-----------|---------|------|
| `校对稿`（默认） | 03_校对稿/ → 04_编辑稿/ → 05_分析稿/ | 全链路替换 |
| `编辑稿` | 04_编辑稿/ → 05_分析稿/ | 不动校对稿 |
| `分析稿` | 05_分析稿/ | 只改分析稿 |

- 用 Grep 递归搜索上述范围内包含错误词的 `.md` 文件
- 每个目录中包含 `*_脱敏.md` 后缀的脱敏版本也一并替换
- **始终排除**：
  - `02_原始稿/` 目录 — ASR 原始转录保持原样，不做修改
  - 任何 `old/` 子目录 — 历史归档不动
  - `meta.yaml` — 元数据文件不参与文本替换

**智能推断起始阶段**：如果用户未指定 `--from` 但在指令中提到了具体文件（如"编辑稿中的XX"），自动推断起始阶段。

### 第四步：执行替换

- 对每个命中文件：先 Read 确认内容，再 Edit（replace_all: true）
- 多条纠错依次处理，每条错误词独立搜索和替换
- 替换是确定性操作，直接执行并报告结果，无需逐文件确认

### 第五步：更新 meta.yaml

通过 meta_io CLI 追加修订记录（统一写入口，自动保序，**不要手写 YAML**）：

```bash
uv run --script {MINT_SCRIPTS}/meta_io.py add-revision "<工作目录>" --type patch --desc "修正'{错误词}'->'{正确词}'" --files "{命中文件相对路径,逗号分隔}" --last-action-desc "词表补丁({纠错条数}条)"
```

- `--files`：传第四步**实际命中替换**的文件相对路径列表（逗号分隔，如 `03_校对稿/x_校对稿.md,04_编辑稿/x_结构化分析.md`）——记录实际受影响文件而非计数，供 next-rules 路径匹配。
- `--last-action-desc`：更新 `current.last_action_desc`；patch 是维护类操作，**不改 `current.cursor`**（cursor 停留在最近流水线阶段）。
- `timestamp` 缺省自动填当前 ISO 时间。
- 如果一次 patch 包含多条纠错，合并为一条 revision，`--desc` 列出所有修正项。

### 第六步：输出变更摘要

```markdown
## Patch 完成

### 词表更新
- 新增 N 条纠错记录到 lessons-learned.md

### 文件替换
| 文件 | 替换次数 |
|------|---------|
| 03_校对稿/{name}_校对稿.md | X 处 |
| 04_编辑稿/{name}_结构化分析.md | X 处 |
| 05_分析稿/要点摘要.md | X 处 |

### 无命中
以下目录中未找到匹配：04_编辑稿/、05_分析稿/
```

## 边界规则

- **02_原始稿/ 绝对不改**：原始 ASR 输出是参照基准，改了就失去对比价值
- **old/ 默认跳过**：除非用户明确说"包括旧版本"
- **替换是确定性操作**：直接执行并报告结果，无需逐文件确认
- **词表是共享资源**：更新后的词表会被 /mint:refine 引用，语境说明要写清楚
- **meta.yaml 修订记录必须更新**：每次 patch 操作都要在 revisions 中留痕

## blocker 自动解除

patch 替换完成后，遍历当前会议 meta.yaml 的 `current.blockers[]`：若某 blocker description 包含本次 patch 的错误词，说明该 ASR 同音歧义已通过词表修正，自动解除（PRD BLOCKER-01）：

```bash
uv run --script {MINT_SCRIPTS}/meta_io.py resolve-blockers "<工作目录>" "<错误词>"
```

日志输出 `自动解除 blocker: <原 description>`。

## 最后一步：更新元数据并输出引导块

1. **计算 next_hints**：
   ```bash
   uv run --script {MINT_SCRIPTS}/meta_io.py compute-next-hints "<工作目录>"
   ```
   （`current.last_action` 已由第五步 `add-revision` 自动刷新；`current.last_action_desc` 也已在第五步通过 `--last-action-desc` 设置。patch 是维护类操作，**不改 `current.cursor`**。）

2. **"返回主流水线"语义覆盖**（PRD 7.3）：patch 修了词表并刷新全部稿件，手工覆盖 next_hints：

   - primary: `/mint:status <工作目录>` — 验证稿件已刷新，查看状态快照
   - alternatives: `/mint:refine <工作目录>`（如发现校对质量下降需重跑）、`/mint:next`（基于新状态查引导）

3. **渲染引导块**：
   - Read `{MINT_REF}/next-hints-template.md`
   - 用覆盖后的 next_hints 填充 `{primary_cmd}` / `{primary_reason}` / `{alternatives_block}`
   - `{alternatives_block}` 按每行 `- {cmd}: {when}` 循环展开，空数组输出单行 `- 无`
   - 原样输出填充后的模板（保留开头的 `---` 分隔线）
